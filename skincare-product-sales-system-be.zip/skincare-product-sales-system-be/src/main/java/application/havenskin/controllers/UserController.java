package application.havenskin.controllers;

import application.havenskin.models.Users;
//import application.havenskin.services.AuthenticationService;
import application.havenskin.services.UserService;
import com.nimbusds.jose.JOSEException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.text.ParseException;
import java.util.List;

@RestController
@RequestMapping("/haven-skin/users")
public class UserController {
//    @Autowired
//    private UserService userService;
//    @Autowired
//    private AuthenticationService authenticationService;
//    @GetMapping
//    public List<Users> getAllUser() {
//        return userService.getAllUsers();
//    }
//    @PostMapping
//    public Users createUser(@RequestBody UserDTO user) {
//      return userService.createUser(user);
//    }
//    @GetMapping("/login")
//    public AuthencationResponse login(@RequestBody AuthencationRequest x) {
//        return authenticationService.authenticate(x);
//    }
//    @GetMapping("/verify-token")
//    public TokenResponse verifyToken(@RequestBody TokenRequest x) throws ParseException, JOSEException {
//        return authenticationService.verifyToken(x);
//    }
//    @PutMapping("/{id}")
//    public Users updateUser(@PathVariable String id, @RequestBody UserDTO user) {
//        return userService.updateUser(id, user);
//    }

}
