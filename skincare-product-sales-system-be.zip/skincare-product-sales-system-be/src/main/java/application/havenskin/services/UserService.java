package application.havenskin.services;

import application.havenskin.dataAccess.UserDTO;
import application.havenskin.mapper.Mapper;
import application.havenskin.models.Users;
import application.havenskin.repositories.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserService {
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private Mapper mapper;
    public List<Users> getAllUsers() {
        return userRepository.findAll();
    }
    public Users getUserById(String id) {
        if(!userRepository.existsById(id)) {
            throw new RuntimeException("User not found");
        }
        return userRepository.findById(id).get();
    }

    public Users createUser(UserDTO user) {
        Users x = mapper.toUsers(user);
        PasswordEncoder passwordEncoder = new BCryptPasswordEncoder(10);
        x.setPassword(passwordEncoder.encode(user.getPassword()));
        return userRepository.save(x);
    }
    public Users updateUser(String id,UserDTO user) {
//        if(!userRepository.existsById(id)) {
//            throw new RuntimeException("User not found");
//        }
//        return userRepository.save(user);
      Users x = userRepository.findById(id).orElseThrow(() -> new RuntimeException("User not found"));
      mapper.toUsers(user);
      return userRepository.save(x);
    }
//    public void deleteUser(String id) {
//        if(!userRepository.existsById(id)) {
//            throw new RuntimeException("User not found");
//        }
//        userRepository.deleteById(id);
//    }

}
