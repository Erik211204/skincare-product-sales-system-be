package application.havenskin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HavenSkinApplicationTests {

    @Test
    void contextLoads() {
    }

}
